package com.example.admin;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewAdapter> {


    private List<GetterSetter> list;
    private Context context;

    public ProductAdapter(List<GetterSetter> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ProductViewAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.product_layout,parent,false);

        return new ProductViewAdapter(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewAdapter holder, int position) {

        final GetterSetter item = list.get(position);
        holder.price.setText(item.getPrice());
        holder.category.setText(item.getCategory());
        holder.subcategory.setText(item.getSubCategory());

        holder.description.setText(item.getDescription());

        try {
            Picasso.get().load(item.getImage()).into(holder.image);
        } catch (Exception e) {
            e.printStackTrace();
        }

        holder.update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context,UpdateProduct.class);
                intent.putExtra("Image",item.getImage());
                intent.putExtra("Price",item.getPrice());
                intent.putExtra("Category",item.getCategory());
                intent.putExtra("Sub-Category",item.getSubCategory());
                intent.putExtra("Description",item.getDescription());
                intent.putExtra("Key",item.getKey());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ProductViewAdapter extends RecyclerView.ViewHolder {

        private TextView price,category,subcategory;
        EditText description;
        ImageView image;
        Button update;

        public ProductViewAdapter(@NonNull View itemView) {
            super(itemView);

            price = itemView.findViewById(R.id.priceupdate);
            category = itemView.findViewById(R.id.categoryupdate);
            subcategory = itemView.findViewById(R.id.subcategoryupdate);

            description = itemView.findViewById(R.id.description);

            image = itemView.findViewById(R.id.imageupdate);

            update = itemView.findViewById(R.id.update);
        }
    }
}
