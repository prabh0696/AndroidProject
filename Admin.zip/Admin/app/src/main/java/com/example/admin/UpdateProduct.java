package com.example.admin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

public class UpdateProduct extends AppCompatActivity {

    private ImageView productimageUpdate;
    private EditText productpriceUpdate,productcategoryUpdate,productsubcategoryUpdate,productdescriptionUpdate;
    private Button Updatebtn,Deletebtn;

    private  final  int REQ =1;
    private Bitmap bitmap=null;

    private ProgressDialog pd;

    private StorageReference storageReference;
    private DatabaseReference reference;
    private String downloadUrl,uniquekey;

    private String image,price,category,subcategory,description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);

        reference = FirebaseDatabase.getInstance().getReference().child("Products");
        storageReference = FirebaseStorage.getInstance().getReference();

        image = getIntent().getStringExtra("Image");
        price = getIntent().getStringExtra("Price");
        category = getIntent().getStringExtra("Category");
        subcategory = getIntent().getStringExtra("Sub-Category");
        description = getIntent().getStringExtra("Description");

        productimageUpdate = findViewById(R.id.productimageUpdate);

        productpriceUpdate = findViewById(R.id.productpriceUpdate);
        productcategoryUpdate = findViewById(R.id.productcategoryUpdate);
        productsubcategoryUpdate = findViewById(R.id.productsubcategoryUpdate);
        productdescriptionUpdate = findViewById(R.id.productdescriptionUpdate);

        Updatebtn = findViewById(R.id.Updatebtn);
        Deletebtn = findViewById(R.id.Deletebtn);

         uniquekey = getIntent().getStringExtra("Key");



        try {
            Picasso.get().load(image).into(productimageUpdate);
        } catch (Exception e) {
            e.printStackTrace();
        }

        productpriceUpdate.setText(price);
        productcategoryUpdate.setText(category);
        productsubcategoryUpdate.setText(subcategory);
        productdescriptionUpdate.setText(description);

        productimageUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        Updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                price = productpriceUpdate.getText().toString();
                category = productcategoryUpdate.getText().toString();
                subcategory = productsubcategoryUpdate.getText().toString();
                description = productdescriptionUpdate.getText().toString();
                checkValidation();
            }
        });

        Deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteData();
            }
        });

    }

    private void checkValidation() {

        if(price.isEmpty()){
            productpriceUpdate.setError("Empty");
            productpriceUpdate.requestFocus();
        }else if(category.isEmpty()) {
            productcategoryUpdate.setError("Empty");
            productcategoryUpdate.requestFocus();
        }else if(subcategory.isEmpty()){
            productsubcategoryUpdate.setError("Empty");
            productsubcategoryUpdate.requestFocus();
        }else if(description.isEmpty()){
            productdescriptionUpdate.setError("Empty");
            productdescriptionUpdate.requestFocus();
        }else {
            if(bitmap == null){
                updateData("");
            }else {
                uploadImage();
            }
        }


    }

    private void updateData(String s) {

        HashMap hp = new HashMap();
        hp.put("Image",s);
        hp.put("Price",price);
        hp.put("Category",category);
        hp.put("Sub-Category",subcategory);
        hp.put("Description",description);
        hp.put("Key",uniquekey);

        reference.child(category).child(uniquekey).updateChildren(hp).addOnSuccessListener(new OnSuccessListener() {
            @Override
            public void onSuccess(Object o) {
                Toast.makeText(UpdateProduct.this,"Product Updated Successfully",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(UpdateProduct.this,Update_Delete_Products.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(UpdateProduct.this,"Something went wrong",Toast.LENGTH_LONG).show();
            }
        });
    }

    private void uploadImage()
         {

            pd.setMessage("Uploading...");
            pd.show();

            ByteArrayOutputStream b = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG,50,b);
            byte[] finalimage = b.toByteArray();
            final StorageReference filepath;
            filepath=storageReference.child(finalimage+"jpg");
            final UploadTask uploadTask  = filepath.putBytes(finalimage);
            uploadTask.addOnCompleteListener(UpdateProduct.this, new OnCompleteListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                    if(task.isSuccessful()){
                        uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                filepath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        downloadUrl = String.valueOf(uri);
                                        updateData(downloadUrl);
                                    }
                                });
                            }
                        });
                    }else{
                        Toast.makeText(getApplicationContext(),"Something went wrong",Toast.LENGTH_LONG).show();
                    }

                }
            })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progressPercent = (100.00*taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            pd.setMessage("Progress:" +(int) progressPercent + "%");
                        }
                    });
        }



    private void deleteData() {

        reference.child(category).child(uniquekey).removeValue()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(UpdateProduct.this,"Product  Deleted Successfully",Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(UpdateProduct.this,Update_Delete_Products.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);

                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(UpdateProduct.this,"Error",Toast.LENGTH_LONG).show();
            }
        });
    }

    private void openGallery(){
        Intent image = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(image,REQ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQ && resultCode == RESULT_OK )
        {

            Uri uri = data.getData();
            try{
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            productimageUpdate.setImageBitmap(bitmap);

        }
    }
}
