package com.example.admin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    CardView AddProduct;
    CardView DeleteProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AddProduct = findViewById(R.id.addproduct);
        AddProduct.setOnClickListener(this);

        DeleteProduct = findViewById(R.id.deleteproduct);
        DeleteProduct.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.addproduct:
                Intent intent = new Intent(MainActivity.this,AddProduct.class);
                startActivity(intent);
                break;
                case R.id.deleteproduct:
                Intent intent1 = new Intent(MainActivity.this,girls_section.class);
                startActivity(intent1);
                break;

        }
    }
}

