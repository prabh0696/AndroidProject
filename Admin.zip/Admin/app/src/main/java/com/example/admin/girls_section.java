package com.example.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class girls_section extends AppCompatActivity {

    private GridView gridView;
    private TextView priceSign,textPrice;
    private ImageView img;
    private Button Buybtn;
    private MultiAutoCompleteTextView multiAutoCompleteTextView;

    private List<GetterSetter> list;

    private DatabaseReference databaseReference, reference;

    private ProductAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_girls_section);

        gridView = findViewById(R.id.gridView);

        priceSign = findViewById(R.id.priceSign);
        textPrice = findViewById(R.id.textprice);
        multiAutoCompleteTextView = findViewById(R.id.multiAutoCompleteTextView);

        img = findViewById(R.id.img);
        Buybtn = findViewById(R.id.Buybtn);

        Intent intent = getIntent();
        textPrice.setText(intent.getStringExtra("Price"));
        multiAutoCompleteTextView.setText(intent.getStringExtra("Description"));
        img.setImageResource(intent.getIntExtra("Image",0));

        databaseReference = FirebaseDatabase.getInstance().getReference().child("Products");

        GirlCloths();


    }

    private void GirlCloths() {

    }
}
