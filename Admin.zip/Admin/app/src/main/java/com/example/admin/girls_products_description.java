package com.example.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class girls_products_description extends AppCompatActivity {

    private GridView gridView;
    private TextView priceSign,textPrice;
    private ImageView img;
    private Button Buybtn;
    private MultiAutoCompleteTextView multiAutoCompleteTextView;

    private List<GetterSetter> list;

    private DatabaseReference databaseReference, reference;

    private ProductAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_girls_products_description);

        gridView = findViewById(R.id.gridView);

        priceSign = findViewById(R.id.priceSign);
        textPrice = findViewById(R.id.textprice);
        multiAutoCompleteTextView = findViewById(R.id.multiAutoCompleteTextView);

        img = findViewById(R.id.img);
        Buybtn = findViewById(R.id.Buybtn);

        Intent intent = getIntent();
        textPrice.setText(intent.getStringExtra("Price"));
        multiAutoCompleteTextView.setText(intent.getStringExtra("Description"));
        img.setImageResource(intent.getIntExtra("Image",0));
    }
}
