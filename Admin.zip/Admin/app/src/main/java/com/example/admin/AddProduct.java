package com.example.admin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.ref.Reference;
import java.util.UUID;

public class AddProduct extends AppCompatActivity {

    private CardView AddImage;
    private final int REQ=1;
    private ImageView ImageView,Addimage;
    private Bitmap bitmap;
    private EditText desc;
    private Button btn;

    private DatabaseReference databaseReference;
    private StorageReference storageReference;
    private FirebaseStorage storage;
    Spinner Category,SubCategory;

    private EditText Price;


    private String category;
    private String subcategory;

    String downloadUrl ="";

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("Products");
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference().child("Products");


        AddImage = findViewById(R.id.addproductitems);
        Addimage = findViewById(R.id.Addimage);
        ImageView = findViewById(R.id.imageview);
        desc = findViewById(R.id.description);
        btn = findViewById(R.id.addproductbtn);
        Category = findViewById(R.id.category);
        SubCategory = findViewById(R.id.sub_category);
        Price = findViewById(R.id.price);

        pd = new ProgressDialog(this);


        String[] items = new  String[]{"Select Category","Women","Men","Boys","Girls"};
        Category.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,items));
        Category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category = Category.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        String[] items1 = new  String[]{"Select Sub-Category","Clothing","Accessories","Shoes"};
        SubCategory.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,items1));
        SubCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                subcategory = SubCategory.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        AddImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(desc.getText().toString().isEmpty()){
                    desc.setError("Empty");
                    desc.requestFocus();
                }else if(bitmap == null){
                    Toast.makeText(AddProduct.this,"Please Select An Image",Toast.LENGTH_LONG).show();

                }else if(Category.equals("Select Category")){
                    Toast.makeText(AddProduct.this,"Please Select Category",Toast.LENGTH_LONG).show();
                }else if(SubCategory.equals("Select Sub-Category")){
                    Toast.makeText(AddProduct.this,"Please Select Sub-Category",Toast.LENGTH_LONG).show();
                }else if(Price == null){
                    Toast.makeText(AddProduct.this,"Please Select Price",Toast.LENGTH_LONG).show();
                }else {

                    pd.setMessage("Uploading...");
                    pd.show();
                    uploadImage();
                }

            }
        });
    }

    private void uploadImage() {

        pd.setMessage("Uploading...");
        pd.show();

        ByteArrayOutputStream b = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,50,b);
        byte[] finalimage = b.toByteArray();
        final StorageReference filepath;
        filepath=storageReference.child(finalimage+"jpg");
        final UploadTask uploadTask  = filepath.putBytes(finalimage);
        uploadTask.addOnCompleteListener(AddProduct.this, new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                if(task.isSuccessful()){
                    uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            filepath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    downloadUrl = String.valueOf(uri);
                                    uploadData();
                                }
                            });
                        }
                    });
                }else{
                    Toast.makeText(getApplicationContext(),"Something went wrong",Toast.LENGTH_LONG).show();
                }

            }
        })
                .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                        double progressPercent = (100.00*taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        pd.setMessage("Progress:" +(int) progressPercent + "%");
                    }
                });
    }


    private void uploadData() {
        databaseReference = databaseReference.child(category);
        final String UniqeKey = databaseReference.push().getKey();
        String Description =desc.getText().toString();
        final String Type = Category.getSelectedItem().toString();
        String SubType = SubCategory.getSelectedItem().toString();
        String price = Price.getText().toString();

        GetterSetter data = new GetterSetter(downloadUrl,Type,SubType,Description,price,UniqeKey);

        databaseReference.child(UniqeKey).setValue(data).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                pd.dismiss();
                Toast.makeText(AddProduct.this,"Product Added",Toast.LENGTH_LONG).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss();
                Toast.makeText(AddProduct.this,"Not working",Toast.LENGTH_LONG).show();
            }
        });
    }


    private void openGallery(){
        Intent image = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(image,REQ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQ && resultCode == RESULT_OK )
        {

            Uri uri = data.getData();
            try{
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            ImageView.setImageBitmap(bitmap);

        }
    }
}
