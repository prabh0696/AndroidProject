package com.example.admin;

public class GetterSetter {

    String Image;
    String Category;
    String SubCategory;
    String Description;
    String Price;
    String Key;

    public GetterSetter(){

    }

    public GetterSetter(String image, String category, String subCategory, String description, String price,String key) {
        Image = image;
        Category = category;
        SubCategory = subCategory;
        Description = description;
        Price = price;
        Key = key;
    }

    public String getKey() {
        return Key;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getSubCategory() {
        return SubCategory;
    }

    public void setSubCategory(String subCategory) {
        SubCategory = subCategory;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }
    public void setKey(String key) { Key = key; }
}
