package com.example.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.List;

public class Update_Delete_Products extends AppCompatActivity {

    private RecyclerView womenDepartment,menDepartment,boysDepartment,girlsDepartment;
    private LinearLayout womennodata,mennodata,boysnodata,girlsnodata;
    private List<GetterSetter>  list1,list2,list3;

    private Button update;

    private DatabaseReference reference,dbref;

    private ProductAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update__delete__products);

        womenDepartment = findViewById(R.id.womenDepartment);
        menDepartment = findViewById(R.id.menDepartment);
        boysDepartment = findViewById(R.id.boysDepartment);
        girlsDepartment = findViewById(R.id.girlsDepartment);

        womennodata = findViewById(R.id.womennodata);
        mennodata = findViewById(R.id.mennodata);
        boysnodata = findViewById(R.id.boysnodata);
        girlsnodata = findViewById(R.id.girlsnodata);

        update = findViewById(R.id.update);

        reference = FirebaseDatabase.getInstance().getReference().child("Products");


        womenDepartment();
        menDepartment();
        girlsDepartment();
        boysDepartment();

    }




    private void womenDepartment() {
        dbref = reference.child("Women");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list1 = new ArrayList<>();
                if(!dataSnapshot.exists()){
                    womennodata.setVisibility(View.VISIBLE);
                    womenDepartment.setVisibility(View.GONE);
                }else{
                    womennodata.setVisibility(View.GONE);
                    womenDepartment.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                        GetterSetter data = snapshot.getValue(GetterSetter.class);
                        list1.add(data);
                    }
                    womenDepartment.setHasFixedSize(true);
                    womenDepartment.setLayoutManager(new LinearLayoutManager(Update_Delete_Products.this));
                    adapter = new ProductAdapter(list1,Update_Delete_Products.this);
                    womenDepartment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                Toast.makeText(Update_Delete_Products.this,databaseError.getMessage(),Toast.LENGTH_LONG).show();

            }
        });
    }

    private void menDepartment() {

        dbref = reference.child("Men");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list2 = new ArrayList<>();
                if(!dataSnapshot.exists()){
                    mennodata.setVisibility(View.VISIBLE);
                    menDepartment.setVisibility(View.GONE);
                }else{
                    mennodata.setVisibility(View.GONE);
                    menDepartment.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                        GetterSetter data = snapshot.getValue(GetterSetter.class);
                        list2.add(data);
                    }
                    menDepartment.setHasFixedSize(true);
                    menDepartment.setLayoutManager(new LinearLayoutManager(Update_Delete_Products.this));
                    adapter = new ProductAdapter(list2,Update_Delete_Products.this);
                    menDepartment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                Toast.makeText(Update_Delete_Products.this,databaseError.getMessage(),Toast.LENGTH_LONG).show();

            }
        });
    }

    public void boysDepartment(){
        dbref = reference.child("Boys");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list3 = new ArrayList<>();
                if(!dataSnapshot.exists()){
                    boysnodata.setVisibility(View.VISIBLE);
                    boysDepartment.setVisibility(View.GONE);
                }else{
                    boysnodata.setVisibility(View.GONE);
                    boysDepartment.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                        GetterSetter data = snapshot.getValue(GetterSetter.class);
                        list3.add(data);
                    }
                    boysDepartment.setHasFixedSize(true);
                    boysDepartment.setLayoutManager(new LinearLayoutManager(Update_Delete_Products.this));
                    adapter = new ProductAdapter(list3,Update_Delete_Products.this);
                    boysDepartment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                Toast.makeText(Update_Delete_Products.this,databaseError.getMessage(),Toast.LENGTH_LONG).show();

            }
        });
    }


    public void girlsDepartment(){
        dbref = reference.child("Girls");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list3 = new ArrayList<>();
                if(!dataSnapshot.exists()){
                    girlsnodata.setVisibility(View.VISIBLE);
                    girlsDepartment.setVisibility(View.GONE);
                }else{
                    girlsnodata.setVisibility(View.GONE);
                    girlsDepartment.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                        GetterSetter data = snapshot.getValue(GetterSetter.class);
                        list3.add(data);
                    }
                    girlsDepartment.setHasFixedSize(true);
                    girlsDepartment.setLayoutManager(new LinearLayoutManager(Update_Delete_Products.this));
                    adapter = new ProductAdapter(list3,Update_Delete_Products.this);
                    girlsDepartment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                Toast.makeText(Update_Delete_Products.this,databaseError.getMessage(),Toast.LENGTH_LONG).show();

            }
        });
    }

}
